export interface DailyPlan {
  id: string;
  date: string;
  menteeId: string;
  comment?: string;
}