import { Box, Heading } from '@chakra-ui/react';

const MentorDashboardPage = () => {
  return (
    <Box p={5}>
      <Heading size="lg" mb={4}>멘토 대시보드</Heading>
    </Box>
  );
};

export default MentorDashboardPage;