import { Box, Heading } from '@chakra-ui/react';

const MenteeFeedbackPage = () => {
  return (
    <Box p={5}>
      <Heading size="lg" mb={4}>피드백 확인</Heading>
    </Box>
  );
};

export default MenteeFeedbackPage;